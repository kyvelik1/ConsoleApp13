![изображение](https://github.com/user-attachments/assets/9e8ce9ea-533f-4f11-ad28-00a73abb754f)
![изображение](https://github.com/user-attachments/assets/913867d0-42a3-415b-9bf7-915373c29fcb)
![изображение](https://github.com/user-attachments/assets/73c4d079-1b6b-404f-acaa-7dceb9609a0a)
![изображение](https://github.com/user-attachments/assets/38831ed5-e82e-40bb-9cdf-8c061f2e4ecf)

![изображение](https://github.com/user-attachments/assets/b5dbb289-b285-4be8-bd1c-1b859489ba43)
![изображение](https://github.com/user-attachments/assets/cf7f3dc9-f4b5-4a6d-9ce8-537d7630d3f8)
![изображение](https://github.com/user-attachments/assets/f6df6af6-c142-41b9-a88f-a4b7875773cb)
![изображение](https://github.com/user-attachments/assets/d1e20297-f9c2-4d15-b213-cce2708e9c27)

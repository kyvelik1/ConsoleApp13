﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass22
    {
        private double _u;
        private double _n;
        private double _y;
        private double _x;

        public MyTaskClass22(double u, double n, double y, double x)
        {
            _u = u;
            _n = n;
            _y = y;
            _x = x;
        }

        public void print()
        {
            Console.WriteLine($"T = {Math.Sin(2 * _u) * 1 * _n * (2 * Math.Pow(_y, 2) + Math.Sqrt(_x))}");
        }
    }
}

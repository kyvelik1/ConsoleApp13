﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass11
    {
        private double _y;
        private double _x;

        public MyTaskClass11(double y, double x)
        {
            _y = y;
            _x = x;
        }   

        public void print()
        {
            Console.WriteLine($"S = {9.756 * Math.Pow(_y, 7) + 2 * Math.Tan(_x)}");
        }
    }
}

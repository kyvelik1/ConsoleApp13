﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass25
    {
        private double _e;
        private double _y;
        private double _f;

        public MyTaskClass25(double e, double y, double f)
        {
            _e = e;
            _y = y;
            _f = f;
        }

        public void print()
        {
            Console.WriteLine($"G = {Math.Pow(_e, 2 * _y) + Math.Sin(Math.Pow(_f, 2))}");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass2
    {
        private double _n2;
        private double _p2;
        private double _y2;
        private double _e2;

        public MyTaskClass2(double n2, double p2, double y2, double e2)
        {
            _n2 = n2;
            _p2 = p2;
            _y2 = y2;
            _e2 = e2;
        }

        public void print()
        {
            Console.WriteLine($"K = {1 * _n2 * (Math.Pow(_p2, 2) + Math.Pow(_y2, 3)) + Math.Pow(_e2, _p2)}");
        }
    }
}

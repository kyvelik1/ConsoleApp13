﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("[1-30]");
            int input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    double t, l;
                    Console.WriteLine("Введите t = ");
                    t = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите l = ");
                    l = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass1 myTaskClass1 = new MyTaskClass1(t, l);
                    myTaskClass1.print();

                    break;

                case 2:
                    double n2, p2, y2, e2;
                    Console.WriteLine("Введите n = ");
                    n2 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите p = ");
                    p2 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y2 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите e2 = ");
                    e2 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass2 myTaskClass2 = new MyTaskClass2(n2, p2, y2, e2);
                    myTaskClass2.print();

                    break;

                case 3:
                    double n3, y3;
                    Console.WriteLine("Введите n = ");
                    n3 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y3 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass3 myTaskClass3 = new MyTaskClass3(n3, y3);
                    myTaskClass3.print();

                    break;

                case 4:
                    double a4, t4;
                    Console.WriteLine("Введите a = ");
                    a4 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите t = ");
                    t4 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass4 myTaskClass4 = new MyTaskClass4(a4, t4);
                    myTaskClass4.print();

                    break;

                case 5:
                    double x5;
                    Console.WriteLine("Введите x = ");
                    x5 = Convert.ToDouble(Console.ReadLine());
                    

                    MyTaskClass5 myTaskClass5 = new MyTaskClass5(x5);
                    myTaskClass5.print();

                    break;

                case 6:
                    double y6, e6;
                    int x6;
                    Console.WriteLine("Введите y = ");
                    y6 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите e = ");
                    e6 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x6 = Convert.ToInt32(Console.ReadLine());

                    MyTaskClass6 myTaskClass6 = new MyTaskClass6(y6, e6, x6);
                    myTaskClass6.print();

                    break;

                case 7:
                    double m7;
                    Console.WriteLine("Введите m = ");
                    m7 = Convert.ToDouble(Console.ReadLine());                   

                    MyTaskClass7 myTaskClass7 = new MyTaskClass7(m7);
                    myTaskClass7.print();

                    break;

                case 8:
                    double y8;
                    Console.WriteLine("Введите y = ");
                    y8 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass8 myTaskClass8 = new MyTaskClass8(y8);
                    myTaskClass8.print();

                    break;

                case 9:
                    double n9, y9, x9;
                    Console.WriteLine("Введите n = ");
                    n9 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y9 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x9 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass9 myTaskClass9 = new MyTaskClass9(n9, y9, x9);
                    myTaskClass9.print();

                    break;

                case 10:
                    double e10, k10, x10;
                    int y10;
                    Console.WriteLine("Введите e = ");
                    e10 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите k = ");
                    k10 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x10 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y10 = Convert.ToInt32(Console.ReadLine());

                    MyTaskClass10 myTaskClass10 = new MyTaskClass10(e10, k10, x10, y10);
                    myTaskClass10.print();

                    break;

                case 11:
                    double y11, x11;
                    Console.WriteLine("Введите y = ");
                    y11 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x11 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass11 myTaskClass11 = new MyTaskClass11(y11, x11);
                    myTaskClass11.print();

                    break;

                case 12:
                    double t12, x12;
                    Console.WriteLine("Введите t = ");
                    t12 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x12 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass12 myTaskClass12 = new MyTaskClass12(t12, x12);
                    myTaskClass12.print();

                    break;

                case 13:
                    double y13;
                    Console.WriteLine("Введите y = ");
                    y13 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass13 myTaskClass13 = new MyTaskClass13(y13);
                    myTaskClass13.print();

                    break;

                case 14:
                    double y14, e14;
                    int x14;
                    Console.WriteLine("Введите y = ");
                    y14 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите e = ");
                    e14 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x14 = Convert.ToInt32(Console.ReadLine());

                    MyTaskClass14 myTaskClass14 = new MyTaskClass14(y14, e14, x14);
                    myTaskClass14.print();

                    break;

                case 15:
                    double y15;
                    Console.WriteLine("Введите y = ");
                    y15 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass15 myTaskClass15 = new MyTaskClass15(y15);
                    myTaskClass15.print();

                    break;

                case 16:
                    double y16;
                    Console.WriteLine("Введите y = ");
                    y16 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass16 myTaskClass16 = new MyTaskClass16(y16);
                    myTaskClass16.print();

                    break;

                case 17:
                    double y17;
                    Console.WriteLine("Введите y = ");
                    y17 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass17 myTaskClass17 = new MyTaskClass17(y17);
                    myTaskClass17.print();

                    break;

                case 18:
                    double y18;
                    Console.WriteLine("Введите y = ");
                    y18 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass18 myTaskClass18 = new MyTaskClass18(y18);
                    myTaskClass18.print();

                    break;

                case 19:
                    double n19, y19, g19;
                    Console.WriteLine("Введите n = ");
                    n19 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y19 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите g = ");
                    g19 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass19 myTaskClass19 = new MyTaskClass19(n19, y19, g19);
                    myTaskClass19.print();

                    break;

                case 20:
                    double e20, k20, y20, x20;
                    Console.WriteLine("Введите e = ");
                    e20 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите k = ");
                    k20 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y20 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x20 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass20 myTaskClass20 = new MyTaskClass20(e20, k20, y20, x20);
                    myTaskClass20.print();

                    break;

                case 21:
                    double e21, y21, h21;
                    Console.WriteLine("Введите e = ");
                    e21 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y21 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите h = ");
                    h21 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass21 myTaskClass21 = new MyTaskClass21(e21, y21, h21);
                    myTaskClass21.print();

                    break;

                case 22:
                    double u22, n22, y22, x22;
                    Console.WriteLine("Введите u = ");
                    u22 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите n = ");
                    n22 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y22 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x22 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass22 myTaskClass22 = new MyTaskClass22(u22, n22, y22, x22);
                    myTaskClass22.print();

                    break;

                case 23:
                    double e23, y23, f23;
                    Console.WriteLine("Введите e = ");
                    e23 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y23 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите f = ");
                    f23 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass23 myTaskClass23 = new MyTaskClass23(e23, y23, f23);
                    myTaskClass23.print();

                    break;

                case 24:
                    double y24;
                    Console.WriteLine("Введите y = ");
                    y24 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass24 myTaskClass24 = new MyTaskClass24(y24);
                    myTaskClass24.print();

                    break;

                case 25:
                    double e25, y25, f25;
                    Console.WriteLine("Введите e = ");
                    e25 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y25 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите f = ");
                    f25 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass25 myTaskClass25 = new MyTaskClass25(e25, y25, f25);
                    myTaskClass25.print();

                    break;

                case 26:
                    double p26;
                    Console.WriteLine("Введите p = ");
                    p26 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass26 myTaskClass26 = new MyTaskClass26(p26);
                    myTaskClass26.print();

                    break;

                case 27:
                    double v27, e27, y27, x27;
                    Console.WriteLine("Введите v = ");
                    v27 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите e = ");
                    e27 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y27 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите x = ");
                    x27 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass27 myTaskClass27 = new MyTaskClass27(v27, e27, y27, x27);
                    myTaskClass27.print();

                    break;

                case 28:
                    double e28, y28, h28;
                    Console.WriteLine("Введите e = ");
                    e28 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y28 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите h = ");
                    h28 = Convert.ToDouble(Console.ReadLine());
                    
                    MyTaskClass28 myTaskClass28 = new MyTaskClass28(e28, y28, h28);
                    myTaskClass28.print();

                    break;

                case 29:
                    double y29;
                    Console.WriteLine("Введите y = ");
                    y29 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass29 myTaskClass29 = new MyTaskClass29(y29);
                    myTaskClass29.print();

                    break;

                case 30:
                    double e30, y30, r30;
                    Console.WriteLine("Введите e = ");
                    e30 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите y = ");
                    y30 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите r = ");
                    r30 = Convert.ToDouble(Console.ReadLine());

                    MyTaskClass30 myTaskClass30 = new MyTaskClass30(e30, y30, r30);
                    myTaskClass30.print();

                    break;
            }
        }
    }
}

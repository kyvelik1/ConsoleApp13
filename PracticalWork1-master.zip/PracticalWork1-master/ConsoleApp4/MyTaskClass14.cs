﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass14
    {
        private double _y;
        private double _e;
        private int _x;

        public MyTaskClass14(double y, double e, int x)
        {
            _y = y;
            _e = e;
            _x = x;
        }

        public void print()
        {
            Console.WriteLine($"R = {Math.Abs(Math.Sqrt(Math.Pow(Math.Sin(_y), 2) + 6.835) + Math.Pow(_e, _x))}");
        }
    }
}

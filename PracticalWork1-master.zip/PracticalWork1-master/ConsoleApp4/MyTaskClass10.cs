﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass10
    {
        private double _e;
        private double _k;
        private double _x;
        private int _y;
        public MyTaskClass10(double e, double k, double x, int y)
        {
            _e = e;
            _k = k;
            _x = x;
            _y = y;
        }

        public void print()
        {
            Console.WriteLine($"U = {Math.Pow(_e, _y) + 7.355 * Math.Pow(_k, 2) + Math.Pow(Math.Cos(_x), 2)}");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass28
    {
        private double _e;
        private double _y;
        private double _h;

        public MyTaskClass28(double e, double y, double h)
        {
            _e = e;
            _y = y;
            _h = h;
        }

        public void print()
        {
            Console.WriteLine($"T = {Math.Pow(_e, _y + _h) + Math.Sqrt(Math.Abs(_y + 1))}");
        }
    }
}

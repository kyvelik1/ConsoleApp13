﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass20
    {
        private double _e;
        private double _k;
        private double _y;
        private double _x;

        public MyTaskClass20(double e, double k, double y, double x)
        {
            _e = e;
            _k = k;
            _y = y;
            _x = x;
        }

        public void print()
        {
            Console.WriteLine($"U = {Math.Pow(_e, _k + _y) + Math.Tan(_x * Math.Sqrt(_y))}");
        }
    }
}

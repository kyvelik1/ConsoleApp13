﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class MyTaskClass27
    {
        private double _v;
        private double _e;
        private double _y;
        private double _x;

        public MyTaskClass27(double v, double e, double y, double x)
        {
            _v = v;
            _e = e;
            _y = y;
            _x = x;
        }

        public void print()
        {
            Console.WriteLine($"W = {1.03 * _v + Math.Pow(_e, 2 * _y) + Math.Tan(Math.Abs(_x))}");
        }
    }
}

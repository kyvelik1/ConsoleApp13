﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp6.Servers
{
    public static class MyNavigation
    {
        public static Frame MyConnect {  get; set; }
    }
}

![изображение](https://github.com/user-attachments/assets/db17c3dc-04da-4883-9e1f-cc41c1a2dc62)
![изображение](https://github.com/user-attachments/assets/0dd21e53-65e3-4644-a132-93ed2132b615)
![изображение](https://github.com/user-attachments/assets/c3f53cee-cffd-4ca4-bdce-15b31f44549b)
![изображение](https://github.com/user-attachments/assets/65d72b30-574c-4da0-b18b-1d39094adbb2)

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp11.Servers
{
    static public class MyNavigation
    {
        static public Frame MyConnect {  get; set; }
    }
}

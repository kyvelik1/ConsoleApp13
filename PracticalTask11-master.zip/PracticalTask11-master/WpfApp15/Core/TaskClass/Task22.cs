﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp15.Core.TaskClass
{
    public class Task22
    {
        public double[] ReverseArray(double[] arr)
        {
            Array.Reverse(arr); 
            return arr;
        }
    }
}

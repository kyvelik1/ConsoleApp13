![изображение](https://github.com/user-attachments/assets/4a3492ac-6477-4979-8972-f1788de10fe9)
![изображение](https://github.com/user-attachments/assets/65f32ea7-8e0d-4819-a920-b3824119d09c)
![изображение](https://github.com/user-attachments/assets/df3f7789-3252-4e3f-9323-352c74670067)
![изображение](https://github.com/user-attachments/assets/5019051a-b2f8-4eba-b4c0-bc2cc159ce64)

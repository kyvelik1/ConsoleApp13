﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp13.Core
{
    public static class MyNavigation
    {
        public static Frame MyConnect {  get; set; }
    }
}
